INSTALLER PLUGIN SLS CHANGE DETECTOR
====================================

Cara pakai:
1. Ekstrak seluruh isi ZIP ini ke satu folder (misal: di Desktop).
2. Klik 2x file: install_plugin.bat
3. Tunggu proses selesai.
4. Buka QGIS → Plugins → Manage and Install Plugins → aktifkan "SLS Change Detector".

Syarat:
- QGIS 3.34.9 sudah terinstal.
- Jalankan installer ini setelah QGIS pernah dibuka minimal sekali.

Tidak perlu instalasi tambahan — plugin siap pakai!

Dibuat oleh: Sugiman + AI